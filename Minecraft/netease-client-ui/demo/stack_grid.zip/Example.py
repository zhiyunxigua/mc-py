# -*- coding: utf-8 -*-
"""
Created on 2025-09-21
模板UI系统
这里主要 提供一个模板
"""
from utils import *


class Main(BaseCustomScreen):
    def __init__(self, namespace, name, param):
        super(Main, self).__init__(namespace, name, param)

    def Create(self): # 当界面加载完成后
        pass

    @ViewBinder.binding(ViewBinder.BF_BindInt, "#stack_grid_example.item_count")
    def OnReturnStackGridCount(self):
        # 返回stack_grid内容的数量，对应json的#stack_grid_example.item_count变量
        return 10

    # 按下时通过re函数计算出按下的是滚动列表中的第几个按钮
    @ViewBinder.binding(ViewBinder.BF_ButtonClickUp, "#button_click")
    def OnButtonClick(self, args):
        # 按钮按下后有个ButtonPath参数是按钮的路径，可以通过路径的名字，获取按钮的index
        # 获取到的路径是字符串，通过re函数计算之后的数据类型是list[str]，所以要先索引0，然后转成int格式
        # 获取到的index是从1开始的，如果需要从0开始，就要-1
        button_index = int(re.compile(r'\d+').findall(args["ButtonPath"].split('/')[-1])[0]) - 1
        print "第 " + str(button_index) + " 个按钮按下啦！"

    @ViewBinder.binding_collection(ViewBinder.BF_BindString, "stack_grid_group", "#button_text")
    def OnReturnButtonText(self, index):
        return "第 §b" + str(index) + "§8 个按钮"

    def OnActive(self):  # UI重新回到栈顶时调用
        pass

    def OnDeactive(self):  # 栈顶UI有其他UI入栈时调用
        pass

    def Destroy(self):  # 销毁时调用
        pass
